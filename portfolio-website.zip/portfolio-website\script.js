/* ===== NAVBAR SCROLL ===== */
const nav = document.getElementById('navbar');
window.addEventListener('scroll', () => nav.classList.toggle('scrolled', scrollY > 50));

/* ===== HAMBURGER + MOBILE DRAWER ===== */
const hamburger = document.getElementById('hamburger');
const drawer    = document.getElementById('mobileDrawer');
const overlay   = document.getElementById('drawerOverlay');

function openDrawer() {
  drawer.classList.add('open');
  overlay.classList.add('open');
  hamburger.classList.add('open');
  hamburger.setAttribute('aria-expanded', 'true');
  document.body.style.overflow = 'hidden';
}
function closeDrawer() {
  drawer.classList.remove('open');
  overlay.classList.remove('open');
  hamburger.classList.remove('open');
  hamburger.setAttribute('aria-expanded', 'false');
  document.body.style.overflow = '';
}

hamburger.addEventListener('click', () => drawer.classList.contains('open') ? closeDrawer() : openDrawer());
document.getElementById('drawerClose').addEventListener('click', closeDrawer);
overlay.addEventListener('click', closeDrawer);

// Close drawer on link click
document.querySelectorAll('.drawer-link').forEach(link => {
  link.addEventListener('click', closeDrawer);
});

/* ===== SMOOTH SCROLL (with navbar offset) ===== */
document.querySelectorAll('a[href^="#"], .ujump').forEach(el => {
  el.addEventListener('click', function(e) {
    const href = this.getAttribute('href') || ('#' + this.dataset.target);
    if (!href || href === '#') return;
    const target = document.querySelector(href);
    if (!target) return;
    e.preventDefault();
    const offset = nav.offsetHeight + 16;
    window.scrollTo({ top: target.offsetTop - offset, behavior: 'smooth' });
  });
});

/* ===== UNIT ACCORDION ===== */
document.querySelectorAll('button.unit-header').forEach(btn => {
  btn.addEventListener('click', function() {
    const block   = this.closest('.unit-block');
    const body    = document.getElementById(this.getAttribute('aria-controls'));
    const isOpen  = block.classList.contains('open');

    // Collapse all
    document.querySelectorAll('.unit-block').forEach(b => {
      b.classList.remove('open');
      b.querySelector('button.unit-header').setAttribute('aria-expanded', 'false');
      const bodyEl = b.querySelector('.unit-content');
      if (bodyEl) bodyEl.classList.add('collapsed');
      const icon = b.querySelector('.toggle-icon');
      if (icon) icon.textContent = '▼';
    });

    // Open clicked if it was closed
    if (!isOpen) {
      block.classList.add('open');
      this.setAttribute('aria-expanded', 'true');
      if (body) body.classList.remove('collapsed');
      const icon = this.querySelector('.toggle-icon');
      if (icon) icon.textContent = '▲';
    }
  });
});

/* ===== UNIT QUICK-JUMP TABS ===== */
document.querySelectorAll('.ujump').forEach(btn => {
  btn.addEventListener('click', function() {
    // Highlight active tab
    document.querySelectorAll('.ujump').forEach(b => b.classList.remove('active'));
    this.classList.add('active');

    const targetId = this.dataset.target;
    const block = document.getElementById(targetId);
    if (!block) return;

    // Open that unit block
    document.querySelectorAll('.unit-block').forEach(b => {
      b.classList.remove('open');
      b.querySelector('button.unit-header').setAttribute('aria-expanded', 'false');
      const bodyEl = b.querySelector('.unit-content');
      if (bodyEl) bodyEl.classList.add('collapsed');
      const icon = b.querySelector('.toggle-icon');
      if (icon) icon.textContent = '▼';
    });
    block.classList.add('open');
    block.querySelector('button.unit-header').setAttribute('aria-expanded', 'true');
    const bodyEl = block.querySelector('.unit-content');
    if (bodyEl) bodyEl.classList.remove('collapsed');
    const icon = block.querySelector('.toggle-icon');
    if (icon) icon.textContent = '▲';

    // Scroll to it
    const offset = nav.offsetHeight + 80;
    window.scrollTo({ top: block.offsetTop - offset, behavior: 'smooth' });
  });
});

/* ===== ACTIVE NAV LINK ===== */
const secs = document.querySelectorAll('section[id]');
window.addEventListener('scroll', () => {
  let cur = '';
  secs.forEach(s => { if (scrollY >= s.offsetTop - 140) cur = s.id; });
  document.querySelectorAll('.nav-links a').forEach(a => {
    const active = a.getAttribute('href') === '#' + cur;
    a.style.color  = active ? '#fff' : '';
    a.style.fontWeight = active ? '600' : '';
  });
});

/* ===== FADE-UP SCROLL ANIMATION ===== */
const animEls = document.querySelectorAll('.team-card,.hl-card,.mini-card,.cm-item,.unit-jumps');
animEls.forEach(el => el.classList.add('fade-up'));
const obs = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('vis'); });
}, { threshold: 0.1 });
animEls.forEach(el => obs.observe(el));

/* ===== BACK TO TOP ===== */
const backTop = document.getElementById('backTop');
window.addEventListener('scroll', () => backTop.classList.toggle('show', scrollY > 400));
backTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

/* ===== CONTACT FORM ===== */
document.getElementById('cForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const btn = document.getElementById('csend');
  btn.textContent = 'Sending…'; btn.disabled = true;
  setTimeout(() => {
    document.getElementById('fok').classList.remove('hidden');
    this.reset();
    btn.textContent = 'Send Message ✉️';
    btn.disabled = false;
  }, 1000);
});

/* ===== SMOOTH 3D TILT on cards ===== */
document.querySelectorAll('.team-card,.hl-card').forEach(card => {
  card.style.transition = 'transform 0.15s ease, border-color 0.3s, box-shadow 0.3s';
  card.addEventListener('mousemove', e => {
    const r = card.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width  - 0.5;
    const y = (e.clientY - r.top)  / r.height - 0.5;
    card.style.transform = `translateY(-6px) rotateX(${-y * 5}deg) rotateY(${x * 5}deg)`;
  });
  card.addEventListener('mouseleave', () => { card.style.transform = ''; });
});
